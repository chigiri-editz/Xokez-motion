package com.xokez.motion

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Neon = Color(0xFF00E6A0)
private val Bg = Color(0xFF101116)
private val Bar = Color(0xFF1D1D1F)
private val Panel = Color(0xFF292A2D)
private val Dim = Color(0xFF9A9A9D)
private val CyanClip = Color(0xFF00BFD6)

class MainActivity : ComponentActivity() {
    fun clearXokezCache(): Boolean = cacheDir.listFiles()?.all { it.deleteRecursively() } ?: true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { XokezEditor(onClearCache = { clearXokezCache() }) }
    }
}

@Composable
private fun XokezEditor(onClearCache: () -> Boolean) {
    var projectName by remember { mutableStateOf("New Project 256") }
    var menuOpen by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf("") }
    var selectedTool by remember { mutableStateOf("Shape") }
    var selectedLayer by remember { mutableStateOf("Rectangle 1") }
    var currentTime by remember { mutableStateOf("00:00:00") }
    var fps by remember { mutableStateOf("60 fps") }
    var ratio by remember { mutableStateOf("4:5") }
    var resolution by remember { mutableStateOf("1080p (FHD)") }
    var importedMedia by remember { mutableStateOf("") }
    var layers by remember { mutableStateOf(listOf("Rectangle 1")) }
    var playing by remember { mutableStateOf(false) }
    var effectSearch by remember { mutableStateOf("") }

    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            importedMedia = uri.lastPathSegment ?: "Imported media"
            layers = layers + importedMedia
            selectedLayer = importedMedia
            dialog = "Imported media: $importedMedia"
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Neon, background = Bg, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            // Project header inspired by the reference editor.
            Row(
                Modifier.fillMaxWidth().height(54.dp).background(Bar).padding(horizontal = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { dialog = "Project list" }, modifier = Modifier.size(42.dp)) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
                }
                TextField(
                    value = projectName,
                    onValueChange = { projectName = it },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Bar, unfocusedContainerColor = Bar,
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedIndicatorColor = Color.DarkGray, unfocusedIndicatorColor = Color.DarkGray
                    ),
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 16.sp)
                )
                IconButton(onClick = { dialog = "settings" }) { Icon(Icons.Default.Settings, "Project settings", tint = Color.White) }
                IconButton(onClick = { dialog = "export" }) { Icon(Icons.Default.OpenInNew, "Export", tint = Color.White) }
            }

            // Preview canvas area.
            Box(
                Modifier.fillMaxWidth().weight(0.95f).background(Color(0xFF131722)).padding(horizontal = 24.dp, vertical = 0.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier.fillMaxHeight().aspectRatio(if (ratio == "16:9") 16f / 9f else if (ratio == "1:1") 1f else if (ratio == "9:16") 9f / 16f else 4f / 5f)
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    if (selectedLayer.startsWith("Rectangle")) {
                        Box(Modifier.size(72.dp).border(1.dp, Color.White).clickable { dialog = "layer" }) {
                            listOf(
                                Alignment.TopStart, Alignment.TopCenter, Alignment.TopEnd,
                                Alignment.CenterStart, Alignment.CenterEnd,
                                Alignment.BottomStart, Alignment.BottomCenter, Alignment.BottomEnd
                            ).forEach { point ->
                                Box(Modifier.align(point).size(8.dp).clip(CircleShape).background(Color.White))
                            }
                        }
                    } else {
                        Text(if (importedMedia.isNotBlank()) "MEDIA PREVIEW" else "X", color = Neon, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Timeline command strip.
            Row(
                Modifier.fillMaxWidth().height(48.dp).background(Bar),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SmallIcon(Icons.Default.Undo, "Undo") { dialog = "Nothing to undo yet" }
                SmallIcon(Icons.Default.Redo, "Redo") { dialog = "Nothing to redo yet" }
                SmallIcon(Icons.Default.SkipPrevious, "Previous") { currentTime = "00:00:00" }
                SmallIcon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play") { playing = !playing }
                SmallIcon(Icons.Default.SkipNext, "Next") { currentTime = "00:00:01" }
                SmallIcon(Icons.Default.Layers, "Layers") { dialog = "layers" }
                SmallIcon(Icons.Default.CenterFocusStrong, "Fit canvas") { dialog = "Canvas fitted" }
            }

            // Playhead/timecode.
            Box(Modifier.fillMaxWidth().height(34.dp).background(Color(0xFF1A1A1B)), contentAlignment = Alignment.Center) {
                Text(currentTime, color = Color.White, fontSize = 15.sp,
                    modifier = Modifier.background(Color(0xFF293146), RoundedCornerShape(3.dp)).padding(horizontal = 10.dp, vertical = 2.dp))
                Box(Modifier.align(Alignment.Center).width(2.dp).fillMaxHeight().background(Color.White))
            }

            // Layer tracks with a vivid clip block.
            Column(Modifier.fillMaxWidth().height(104.dp).background(Color(0xFF151516)).padding(horizontal = 8.dp, vertical = 5.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Visibility, null, tint = Dim, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(selectedLayer, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(0.36f), maxLines = 1)
                    Box(
                        Modifier.weight(0.64f).height(30.dp).clip(RoundedCornerShape(4.dp))
                            .background(CyanClip).clickable { dialog = "layer" }.padding(horizontal = 8.dp),
                        contentAlignment = Alignment.CenterStart
                    ) { Text(selectedLayer, color = Color(0xFF08232A), fontSize = 12.sp, maxLines = 1) }
                }
                Spacer(Modifier.height(7.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("00:00", color = Dim, fontSize = 10.sp)
                    Text("00:02", color = Dim, fontSize = 10.sp)
                    Text("00:04", color = Dim, fontSize = 10.sp)
                    Text("00:06", color = Dim, fontSize = 10.sp)
                }
            }

            // Tool categories.
            Row(
                Modifier.fillMaxWidth().background(Color(0xFF08090B)).horizontalScroll(rememberScrollState()).padding(horizontal = 5.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                listOf("Shape", "Media", "Audio", "Object / Element", "Template", "Freehand").forEach { tool ->
                    val active = selectedTool == tool
                    Column(
                        Modifier.width(91.dp).clip(RoundedCornerShape(8.dp))
                            .background(if (active) Color(0xFF12372F) else Color(0xFF101114))
                            .clickable {
                                selectedTool = tool
                                when (tool) {
                                    "Media" -> mediaPicker.launch(arrayOf("video/*", "image/*"))
                                    "Audio" -> mediaPicker.launch(arrayOf("audio/*"))
                                    "Template" -> dialog = "Templates"
                                }
                            }.padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            when (tool) {
                                "Shape" -> Icons.Default.Category
                                "Media" -> Icons.Default.Image
                                "Audio" -> Icons.Default.MusicNote
                                "Template" -> Icons.Default.Dashboard
                                "Freehand" -> Icons.Default.Gesture
                                else -> Icons.Default.AutoAwesome
                            }, null, tint = if (active) Neon else Color.White, modifier = Modifier.size(22.dp)
                        )
                        Text(tool, color = if (active) Neon else Color.White, fontSize = 10.sp, textAlign = TextAlign.Center, maxLines = 2)
                    }
                }
                Column(
                    Modifier.width(65.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF101114))
                        .clickable { selectedTool = "Vector" }.padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Edit, null, tint = Color.White)
                    Text("Vector", color = Color.White, fontSize = 10.sp)
                }
                Column(
                    Modifier.width(65.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF101114))
                        .clickable { selectedTool = "Text"; dialog = "Add text layer" }.padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.TextFields, null, tint = Color.White)
                    Text("Text", color = Color.White, fontSize = 10.sp)
                }
            }

            // Tools grid / effect browser shortcut.
            LazyColumn(
                Modifier.fillMaxWidth().weight(0.75f).background(Color(0xFF111214)),
                contentPadding = PaddingValues(8.dp)
            ) {
                item {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("$selectedTool tools", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text("＋", color = Neon, fontSize = 24.sp, modifier = Modifier.clickable {
                            when (selectedTool) {
                                "Media" -> mediaPicker.launch(arrayOf("video/*", "image/*"))
                                "Audio" -> mediaPicker.launch(arrayOf("audio/*"))
                                else -> dialog = "Add layer"
                            }
                        })
                    }
                    Spacer(Modifier.height(8.dp))
                    if (selectedTool == "Shape") {
                        val shapes = listOf("●" to "Circle", "■" to "Square", "+" to "Plus", "◜" to "Arc",
                            "▲" to "Triangle", "▰" to "Rounded", "◆" to "Diamond", "⬟" to "Polygon",
                            "♥" to "Heart", "★" to "Star", "／" to "Line", "➜" to "Arrow")
                        shapes.chunked(4).forEach { rowItems ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                rowItems.forEach { (glyph, name) ->
                                    Column(
                                        Modifier.weight(1f).padding(bottom = 7.dp).height(56.dp)
                                            .clip(RoundedCornerShape(5.dp)).background(Panel)
                                            .clickable {
                                                selectedLayer = "$name 1"
                                                layers = layers + selectedLayer
                                                dialog = "$name added to timeline"
                                            },
                                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                                    ) {
                                        Text(glyph, color = Color.LightGray, fontSize = 24.sp)
                                        Text(name, color = Dim, fontSize = 9.sp)
                                    }
                                }
                            }
                        }
                    } else {
                        val tools = when (selectedTool) {
                            "Media" -> listOf("Import Video", "Import Image", "Crop", "Fit / Fill")
                            "Audio" -> listOf("Import Audio", "Volume", "Fade In", "Fade Out")
                            "Text" -> listOf("Add Text", "Font", "Color", "Text Animation")
                            "Object / Element" -> listOf("Group", "Duplicate", "Parent", "Anchor")
                            "Freehand" -> listOf("Brush", "Stroke", "Color", "Smooth")
                            "Vector" -> listOf("Pen Tool", "Path", "Stroke", "Fill")
                            else -> listOf("Color & Fill", "Border & Shadow", "Blending & Opacity", "Move & Transform", "Presets", "Effects")
                        }
                        tools.forEach { name ->
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(6.dp))
                                    .background(Panel).clickable {
                                        when (name) {
                                            "Import Video" -> mediaPicker.launch(arrayOf("video/*"))
                                            "Import Image" -> mediaPicker.launch(arrayOf("image/*"))
                                            "Import Audio" -> mediaPicker.launch(arrayOf("audio/*"))
                                            "Effects", "Add Effect" -> dialog = "effects"
                                            else -> dialog = name
                                        }
                                    }.padding(13.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Tune, null, tint = Neon, modifier = Modifier.size(19.dp))
                                Spacer(Modifier.width(12.dp))
                                Text(name, color = Color.White, fontSize = 13.sp)
                                Spacer(Modifier.weight(1f))
                                Icon(Icons.Default.ChevronRight, null, tint = Dim)
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Color & Fill", "Border & Shadow", "Blending & Opacity", "Move & Transform", "Presets", "Effects").forEach { label ->
                            // Rendered as compact clickable tool chips.
                        }
                    }
                    if (selectedTool != "Shape") {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Color & Fill", "Move & Transform", "Effects").forEach { label ->
                                Box(Modifier.weight(1f).clip(RoundedCornerShape(6.dp)).background(Color(0xFF202124))
                                    .clickable { dialog = if (label == "Effects") "effects" else label }.padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center) {
                                    Text(label, color = Color.LightGray, fontSize = 9.sp, textAlign = TextAlign.Center)
                                }
                            }
                        }
                    }
                }
            }
        }

        if (dialog == "settings") {
            AlertDialog(
                onDismissRequest = { dialog = "" },
                title = { Text("Project Settings") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Aspect ratio", color = Dim)
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            listOf("16:9", "9:16", "4:5", "1:1").forEach { value ->
                                FilterChip(selected = ratio == value, onClick = { ratio = value }, label = { Text(value) })
                            }
                        }
                        Text("Resolution")
                        listOf("720p (HD)", "1080p (FHD)", "1440p (QHD)", "4K").forEach {
                            Row(Modifier.fillMaxWidth().clickable { resolution = it }, verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = resolution == it, onClick = { resolution = it })
                                Text(it)
                            }
                        }
                        Text("Frame rate")
                        listOf("30 fps", "60 fps", "90 fps", "120 fps").forEach {
                            Row(Modifier.fillMaxWidth().clickable { fps = it }, verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = fps == it, onClick = { fps = it })
                                Text(it)
                            }
                        }
                        Text("Selected: $resolution • $fps", color = Dim, fontSize = 12.sp)
                    }
                },
                confirmButton = { TextButton(onClick = { dialog = "" }) { Text("Done") } }
            )
        } else if (dialog == "export") {
            AlertDialog(
                onDismissRequest = { dialog = "" },
                title = { Text("Export Video") },
                text = { Text("Export settings: $resolution, $fps. The rendering engine is not connected in this prototype yet.") },
                confirmButton = { TextButton(onClick = { dialog = ""; }) { Text("OK") } }
            )
        } else if (dialog == "effects") {
            AlertDialog(
                onDismissRequest = { dialog = "" },
                title = { Text("Effect Browser") },
                text = {
                    Column {
                        OutlinedTextField(value = effectSearch, onValueChange = { effectSearch = it }, label = { Text("Search effects") }, singleLine = true)
                        Spacer(Modifier.height(8.dp))
                        val effects = listOf("Gaussian Blur", "Directional Blur", "Chroma Key", "Glow", "Hue Shift", "Saturation / Vibrance", "Color Gradient", "Tiles", "Stripes", "Shadow", "Wipe", "Solid Color")
                            .filter { it.contains(effectSearch, ignoreCase = true) }
                        effects.forEach { effect ->
                            Text(effect, color = Color.White, modifier = Modifier.fillMaxWidth().clickable {
                                dialog = "$effect selected"
                            }.padding(vertical = 7.dp))
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { dialog = "" }) { Text("Close") } }
            )
        } else if (dialog == "layers") {
            AlertDialog(
                onDismissRequest = { dialog = "" },
                title = { Text("Timeline Layers") },
                text = {
                    Column {
                        layers.forEach { layer ->
                            Row(Modifier.fillMaxWidth().clickable { selectedLayer = layer; dialog = "" }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Layers, null, tint = Neon)
                                Spacer(Modifier.width(8.dp))
                                Text(layer)
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { dialog = "" }) { Text("Done") } }
            )
        } else if (dialog == "layer") {
            AlertDialog(
                onDismissRequest = { dialog = "" },
                title = { Text(selectedLayer) },
                text = { Text("Layer tools: Color & Fill, Border & Shadow, Blending & Opacity, Move & Transform, Presets and Effects.") },
                confirmButton = { TextButton(onClick = { dialog = "effects" }) { Text("Effects") } },
                dismissButton = { TextButton(onClick = { dialog = "" }) { Text("Close") } }
            )
        } else if (dialog == "Add layer") {
            AlertDialog(
                onDismissRequest = { dialog = "" },
                title = { Text("Add Layer") },
                text = { Text("Choose a category below to add content to your project.") },
                confirmButton = { TextButton(onClick = { selectedTool = "Shape"; dialog = "" }) { Text("Shapes") } },
                dismissButton = { TextButton(onClick = { dialog = ""; mediaPicker.launch(arrayOf("video/*", "image/*")) }) { Text("Media") } }
            )
        } else if (dialog == "Add text layer") {
            var textValue by remember { mutableStateOf("Your text") }
            AlertDialog(
                onDismissRequest = { dialog = "" },
                title = { Text("Add Text Layer") },
                text = { OutlinedTextField(value = textValue, onValueChange = { textValue = it }, label = { Text("Text") }) },
                confirmButton = { TextButton(onClick = { selectedLayer = textValue; layers = layers + textValue; selectedTool = "Text"; dialog = "Text layer added" }) { Text("Add") } },
                dismissButton = { TextButton(onClick = { dialog = "" }) { Text("Cancel") } }
            )
        } else if (dialog == "Clear Cache") {
            AlertDialog(
                onDismissRequest = { dialog = "" },
                title = { Text("Clear cache?") },
                text = { Text("Temporary app cache will be removed. Saved projects are not intentionally deleted.") },
                confirmButton = { TextButton(onClick = { onClearCache(); dialog = "Cache cleared" }) { Text("Clear Cache") } },
                dismissButton = { TextButton(onClick = { dialog = "" }) { Text("Cancel") } }
            )
        } else if (dialog.isNotBlank()) {
            AlertDialog(
                onDismissRequest = { dialog = "" },
                text = { Text(dialog) },
                confirmButton = { TextButton(onClick = { dialog = "" }) { Text("OK") } }
            )
        }

        // Hamburger menu overlay entry point: use long-press on project title area is not ideal,
        // so expose it from a top-bar overflow shortcut.
    }
}

@Composable
private fun SmallIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, action: () -> Unit) {
    IconButton(onClick = action, modifier = Modifier.size(38.dp)) {
        Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(21.dp))
    }
}
