# Xokez Motion - Alight Motion-inspired Android starter

This is a native Kotlin + Jetpack Compose starter project inspired by the general layout of mobile motion editors.
It is not affiliated with Alight Motion and does not copy its branding.

## Included
- Dark editor layout, project title, preview canvas and timeline strip
- Shape tools and layer selection
- Android document picker for images, videos, and audio
- Effect browser mock panel
- Project settings with aspect ratio, resolution, and frame-rate preference including 120 fps
- Clear Cache confirmation
- Export panel placeholder

## Not yet implemented
- Real video decoding/rendering into the preview
- Keyframe animation and real-time timeline playback
- Actual effect processing
- Video rendering/export engine
- Persistent project format and undo/redo history

## Build
Open this folder in a compatible Android IDE/build environment and build the `app` module.
The output APK is not included; this ZIP contains source code only.
